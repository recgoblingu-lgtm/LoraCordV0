# LoraCordV0


## Custom Rich Presence

LoraCord is primarily a browser userscript/theme collection, so Rich Presence runs as a small companion process in the Chromebook Linux container. This is intentional: a browser userscript cannot directly use Discord's local IPC connection. The companion connects to the Discord desktop client and publishes the activity configured below.

### What you need

Install the Discord desktop application inside Chromebook Linux, then create a Discord application at the [Discord Developer Portal](https://discord.com/developers/applications). Copy its **Application ID**. In the application's **Rich Presence > Art Assets** section, upload an image with the key `loracord`, or change `LORACORD_LARGE_IMAGE` to match an existing asset key.

### Install and run

```bash
cd ~/LoraCordV0
npm install
npm start -- YOUR_DISCORD_APPLICATION_ID
```

Keep the process running while Discord is open. Stop it with `Ctrl+C`. If Discord is not running yet, the program retries every five seconds.

You can customize the activity without editing code:

```bash
export LORACORD_CLIENT_ID=YOUR_DISCORD_APPLICATION_ID
export LORACORD_DETAILS="Building my custom Discord setup"
export LORACORD_STATE="LoraCordV0 on ChromeOS"
export LORACORD_LARGE_IMAGE=loracord
export LORACORD_LARGE_TEXT="LoraCord custom theme"
npm start
```

The optional button variables add one Rich Presence button:

```bash
export LORACORD_BUTTON_LABEL="Open LoraCord"
export LORACORD_BUTTON_URL="https://github.com/recgoblingu-lgtm/LoraCordV0"
npm start
```

The URL must be a valid public `https://` link. Do not put your Client ID in a public commit or paste it into a userscript. The Client ID is not a bot token, but keeping configuration in environment variables makes the repository safer to share.

### Chromebook notes

The Linux container must be allowed to run Linux GUI applications, and the Discord desktop client must be open in that same Linux environment. Discord in a normal Chrome tab is not enough for this IPC-based method. If your Chromebook cannot run the Discord Linux client, use the browser-only fallback: the LoraCord themes and dashboard still work, but Rich Presence will not be available.

### Available environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `LORACORD_CLIENT_ID` | none | Discord application ID; required unless passed as the first argument |
| `LORACORD_DETAILS` | `Customizing Discord with LoraCord` | Main activity line |
| `LORACORD_STATE` | `LoraCordV0 on Chromebook Linux` | Secondary activity line |
| `LORACORD_LARGE_IMAGE` | `loracord` | Discord asset key |
| `LORACORD_LARGE_TEXT` | `LoraCordV0` | Large-image hover text |
| `LORACORD_SMALL_IMAGE` | empty | Optional small asset key |
| `LORACORD_SMALL_TEXT` | empty | Optional small-image hover text |
| `LORACORD_BUTTON_LABEL` | empty | Optional button text |
| `LORACORD_BUTTON_URL` | empty | Optional button URL |

### Troubleshooting

If the activity does not appear, first confirm that the Discord desktop client is open, that its application ID matches the value passed to the runner, and that the image key exists in the Developer Portal. Then run `npm start` directly and read the printed connection error. Rich Presence is not supported by the Discord web client through this local IPC method.
