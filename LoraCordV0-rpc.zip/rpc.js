#!/usr/bin/env node
'use strict';

const RPC = require('discord-rpc');

const CLIENT_ID = process.env.LORACORD_CLIENT_ID || process.argv[2];
const DETAILS = process.env.LORACORD_DETAILS || 'Customizing Discord with LoraCord';
const STATE = process.env.LORACORD_STATE || 'LoraCordV0 on Chromebook Linux';
const LARGE_IMAGE_KEY = process.env.LORACORD_LARGE_IMAGE || 'loracord';
const LARGE_IMAGE_TEXT = process.env.LORACORD_LARGE_TEXT || 'LoraCordV0';
const SMALL_IMAGE_KEY = process.env.LORACORD_SMALL_IMAGE || '';
const SMALL_IMAGE_TEXT = process.env.LORACORD_SMALL_TEXT || '';
const BUTTON_LABEL = process.env.LORACORD_BUTTON_LABEL || '';
const BUTTON_URL = process.env.LORACORD_BUTTON_URL || '';
const START_TIME = Date.now();

if (!CLIENT_ID) {
  console.error('Missing Discord application Client ID.');
  console.error('Run: LORACORD_CLIENT_ID=your_id npm start');
  console.error('You can also pass it as the first argument: npm start -- your_id');
  process.exit(1);
}

const client = new RPC.Client({ transport: 'ipc' });
let shuttingDown = false;
let reconnectTimer;

function buildActivity() {
  const activity = {
    details: DETAILS,
    state: STATE,
    startTimestamp: START_TIME,
    largeImageKey: LARGE_IMAGE_KEY,
    largeImageText: LARGE_IMAGE_TEXT,
    instance: false
  };

  if (SMALL_IMAGE_KEY) {
    activity.smallImageKey = SMALL_IMAGE_KEY;
    activity.smallImageText = SMALL_IMAGE_TEXT;
  }

  if (BUTTON_LABEL && BUTTON_URL) {
    activity.buttons = [{ label: BUTTON_LABEL, url: BUTTON_URL }];
  }

  return activity;
}

async function publish() {
  await client.setActivity(buildActivity());
  console.log(`[LoraCord RPC] Connected. Showing: ${DETAILS} — ${STATE}`);
}

function scheduleReconnect() {
  if (shuttingDown || reconnectTimer) return;
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = undefined;
    try {
      await client.login({ clientId: CLIENT_ID });
    } catch (error) {
      console.error(`[LoraCord RPC] Discord is unavailable: ${error.message}`);
      scheduleReconnect();
    }
  }, 5000);
}

client.on('ready', () => {
  publish().catch((error) => {
    console.error(`[LoraCord RPC] Could not publish activity: ${error.message}`);
    scheduleReconnect();
  });
});

client.on('disconnected', () => {
  console.warn('[LoraCord RPC] Disconnected. Retrying in 5 seconds...');
  scheduleReconnect();
});

async function shutdown() {
  shuttingDown = true;
  if (reconnectTimer) clearTimeout(reconnectTimer);
  try {
    await client.destroy();
  } catch (_) {
    // Discord may already be closed; shutdown should still complete cleanly.
  }
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

client.login({ clientId: CLIENT_ID }).catch((error) => {
  console.error(`[LoraCord RPC] Initial connection failed: ${error.message}`);
  scheduleReconnect();
});
